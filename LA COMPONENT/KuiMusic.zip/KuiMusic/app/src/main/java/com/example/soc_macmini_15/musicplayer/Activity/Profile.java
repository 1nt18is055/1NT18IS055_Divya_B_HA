package com.example.soc_macmini_15.musicplayer.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.example.soc_macmini_15.musicplayer.R;

public class Profile extends AppCompatActivity {
    EditText name;
    Button b;
    RadioGroup radioSexGroup;
    RadioButton radioSexButton;
    ImageView imgv;
    int images[]={R.drawable.male,R.drawable.female};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        radioSexGroup = findViewById(R.id.radioSex);
        imgv = findViewById(R.id.img);
        name = findViewById(R.id.username);
        b = findViewById(R.id.save);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedId = radioSexGroup.getCheckedRadioButtonId();


                if (selectedId == R.id.radioMale) {
                    imgv.setImageResource(images[0]);

                }



                else{
                    imgv.setImageResource(images[1]);
                }
            }
        });
    }
}