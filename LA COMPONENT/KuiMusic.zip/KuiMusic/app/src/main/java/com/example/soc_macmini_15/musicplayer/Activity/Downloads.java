package com.example.soc_macmini_15.musicplayer.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

import com.example.soc_macmini_15.musicplayer.R;

public class Downloads extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_downloads);

        WebView w = findViewById(R.id.web);
        w.loadUrl("https://mail.mymp3song.guru/categorylist/44/a_to_z_bollywood_mp3_songs/default/1");
    }
}