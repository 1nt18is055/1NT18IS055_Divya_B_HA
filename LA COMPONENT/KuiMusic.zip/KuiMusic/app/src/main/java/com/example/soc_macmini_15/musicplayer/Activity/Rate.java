package com.example.soc_macmini_15.musicplayer.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
// Import Rating classes
import com.hsalf.smilerating.BaseRating;
import com.hsalf.smilerating.SmileRating;

import com.example.soc_macmini_15.musicplayer.R;

public class Rate extends AppCompatActivity {
    private static final String TAG = "App";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate);

        Button submit = findViewById(R.id.button1);


        final SmileRating smileRating = findViewById(R.id.smile_rating);

        smileRating.setOnSmileySelectionListener(new SmileRating.OnSmileySelectionListener() {
            @Override
            public void onSmileySelected(@BaseRating.Smiley int smiley, boolean reselected) {

                // Retrieve the value of the bar dinamically
                // level is from 1 to 5
                // Will return 0 if NONE selected
                int level = smileRating.getRating();

                // reselected is false when user selects different smiley that previously selected one
                // true when the same smiley is selected.
                // Except if it first time, then the value will be false.
                switch (smiley) {
                    case SmileRating.BAD:
                        Log.i(TAG, "Bad");
                        Toast.makeText(getApplicationContext(), "BAD!", Toast.LENGTH_SHORT).show();
                        break;
                    case SmileRating.GOOD:
                        Log.i(TAG, "Good");
                        Toast.makeText(getApplicationContext(), "GOOD!", Toast.LENGTH_SHORT).show();
                        break;
                    case SmileRating.GREAT:
                        Log.i(TAG, "Great");
                        Toast.makeText(getApplicationContext(), "GREAT!", Toast.LENGTH_SHORT).show();
                        break;
                    case SmileRating.OKAY:
                        Log.i(TAG, "Okay");
                        Toast.makeText(getApplicationContext(), "OKAY!", Toast.LENGTH_SHORT).show();
                        break;
                    case SmileRating.TERRIBLE:
                        Log.i(TAG, "Terrible");
                        Toast.makeText(getApplicationContext(), "TERRIBLE!", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Thank you for your Feedback", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
